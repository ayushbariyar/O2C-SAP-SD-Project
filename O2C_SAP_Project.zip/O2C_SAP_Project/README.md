# Order-to-Cash (O2C) — SAP SD Capstone Project

## Student Details
| Field | Details |
|-------|---------|
| **Name** | [Your Full Name] |
| **Roll Number** | [Your Roll Number] |
| **Batch / Program** | [Your Batch & Program] |
| **Module** | SAP Sales & Distribution (SD) |
| **Submission Date** | April 21, 2026 |

---

## Project Overview

This project demonstrates the complete **Order-to-Cash (O2C)** business cycle
implemented using **SAP S/4HANA 2023 — Sales & Distribution (SD)** module.

**Company Used:** GlobalTech Industries (Fictitious)  
**Customer Used:** TechMart Pvt. Ltd. (Fictitious)

---

## O2C Process Steps

| Step | Transaction | T-Code | Output Document |
|------|------------|--------|-----------------|
| 1 | Create Inquiry | VA11 | Inquiry No. |
| 2 | Create Quotation | VA21 | Quotation No. |
| 3 | Create Sales Order | VA01 | Sales Order No. |
| 4 | Create Outbound Delivery | VL01N | Delivery No. |
| 5 | Post Goods Issue | VL02N | Material Doc. |
| 6 | Create Billing Document | VF01 | Invoice No. |
| 7 | Post Incoming Payment | F-28 | Accounting Doc. |
| 8 | Clear Open Items | F-32 | Cleared Entry |

---

## Folder Structure

```
O2C_SAP_Project/
│
├── README.md                        ← This file
├── O2C_SAP_SD_Project.pdf           ← Main project documentation (submit this)
├── O2C_Step_by_Step_Guide.md        ← Detailed process guide with all steps
│
└── Screenshots/                     ← Add your SAP screenshots here
    ├── 01_Inquiry_VA11.png
    ├── 02_Quotation_VA21.png
    ├── 03_SalesOrder_VA01.png
    ├── 04_Delivery_VL01N.png
    ├── 05_GoodsIssue_VL02N.png
    ├── 06_Billing_VF01.png
    ├── 07_Payment_F28.png
    └── 08_DocumentFlow.png
```

---

## How to Read This Project

1. Start with **O2C_SAP_SD_Project.pdf** for full documentation
2. Follow **O2C_Step_by_Step_Guide.md** to understand each SAP transaction
3. Screenshots folder contains screen captures from SAP S/4HANA 2023

---

## Key SAP Concepts Covered

- Sales Document Types (OR — Standard Order)
- Pricing Procedure (RVAA01) with conditions PR00, MWST
- Availability to Promise (ATP) Check
- Outbound Delivery & Transfer Order
- Post Goods Issue (PGI) — MM/FI integration
- Billing & Revenue Recognition
- Accounts Receivable — FI integration
- Document Flow traceability in SAP

---

## Submission

- **Google Form:** https://forms.gle/2SF1Hw4jpu1G1Tc58
- **Deadline:** April 21, 2026 | 11:59 PM (Strict)
