# O2C Step-by-Step Process Guide — SAP SD

**Project:** Order-to-Cash End-to-End Implementation  
**System:** SAP S/4HANA 2023  
**Company:** GlobalTech Industries | **Customer:** TechMart Pvt. Ltd.

---

## What is Order-to-Cash (O2C)?

Order-to-Cash is an end-to-end business process that starts when a **customer places an order**
and ends when the **company receives and records the payment**. It spans three SAP modules:

- **SD (Sales & Distribution)** — Orders, Delivery, Billing
- **MM (Materials Management)** — Inventory reduction on Goods Issue
- **FI (Financial Accounting)** — Accounting entries, A/R management

---

## STEP 1 — Create Sales Inquiry

**T-Code:** `VA11`  
**Menu Path:** Logistics → Sales & Distribution → Sales → Inquiry → Create

### What it is:
A customer contacts GlobalTech asking for pricing before committing to a purchase.

### How to do it:
1. Open transaction `VA11`
2. **Inquiry Type:** IN
3. **Sales Organization:** 1000
4. **Distribution Channel:** 10
5. **Division:** 00
6. Press **Enter**
7. Fill in:
   - **Sold-to Party:** (Customer number for TechMart)
   - **Valid From / Valid To:** Date range
   - **Material:** (e.g., MAT-001 — Laptop)
   - **Quantity:** 10 PC
8. Click **Save** (Ctrl+S)
9. Note the **Inquiry Number** generated (e.g., 10000001)

---

## STEP 2 — Create Quotation

**T-Code:** `VA21`  
**Menu Path:** Logistics → Sales & Distribution → Sales → Quotation → Create

### What it is:
A formal price offer sent to the customer based on the inquiry.

### How to do it:
1. Open transaction `VA21`
2. **Quotation Type:** QT
3. **Sales Org / Dist. Channel / Division:** Same as above
4. Press **Enter**
5. In **Create with Reference**, enter the Inquiry Number
6. Click **Copy**
7. Verify:
   - Pricing conditions (PR00 — Base Price)
   - Tax conditions (MWST)
   - Validity period
8. Click **Save**
9. Note the **Quotation Number** (e.g., 20000001)

---

## STEP 3 — Create Sales Order

**T-Code:** `VA01`  
**Menu Path:** Logistics → Sales & Distribution → Sales → Order → Create

### What it is:
The **core document** of O2C. It confirms the customer's purchase and triggers availability check.

### How to do it:
1. Open transaction `VA01`
2. **Order Type:** OR (Standard Order)
3. **Sales Org / Dist. Channel / Division:** 1000 / 10 / 00
4. Press **Enter**
5. Click **Create with Reference** → Enter Quotation Number → **Copy**
6. Verify all details:
   - **Sold-to Party / Ship-to Party:** TechMart Pvt. Ltd.
   - **PO Number:** (Customer's purchase order number)
   - **Requested Delivery Date:** Enter date
   - **Material & Quantity:** MAT-001 / 10 PC
7. Check **Availability** (green = stock available)
8. Check **Pricing** tab — verify Net Value
9. Click **Save**
10. Note the **Sales Order Number** (e.g., 1000XXXX)

> **Key Check:** Go to VA03 → Display Sales Order → Check Document Flow

---

## STEP 4 — Create Outbound Delivery

**T-Code:** `VL01N`  
**Menu Path:** Logistics → Sales & Distribution → Shipping → Outbound Delivery → Create

### What it is:
Initiates the physical shipment process — warehouse picks the goods for dispatch.

### How to do it:
1. Open transaction `VL01N`
2. **Shipping Point:** (e.g., SP01)
3. **Selection Date:** Today's date or delivery date
4. **Sales Order:** Enter Sales Order number
5. Press **Enter**
6. Verify:
   - **Delivery Quantity:** Should match order quantity (10 PC)
   - **Batch / Storage Location:** Check warehouse details
7. **Pick Quantity:** Enter 10 in Picked Qty field
8. Click **Save**
9. Note the **Delivery Document Number** (e.g., 80000XXX)

---

## STEP 5 — Post Goods Issue (PGI)

**T-Code:** `VL02N`  
**Menu Path:** Logistics → Sales & Distribution → Shipping → Outbound Delivery → Change

### What it is:
Physically records that goods have LEFT the warehouse. This reduces inventory (MM) and creates an accounting entry (FI).

### How to do it:
1. Open transaction `VL02N`
2. Enter **Delivery Document Number**
3. Press **Enter**
4. Click **Post Goods Issue** button
5. System confirms: "Goods Issue posted"
6. **SAP automatically creates:**
   - Material Document (stock reduced)
   - Accounting Document: Dr: Cost of Goods Sold / Cr: Inventory

---

## STEP 6 — Create Billing Document (Invoice)

**T-Code:** `VF01`  
**Menu Path:** Logistics → Sales & Distribution → Billing → Billing Document → Create

### What it is:
Creates the customer invoice. SAP automatically posts revenue in FI (Accounts Receivable).

### How to do it:
1. Open transaction `VF01`
2. Enter **Delivery Document Number**
3. Press **Enter**
4. Verify:
   - **Billing Type:** F2 (Invoice)
   - **Net Value / Tax Amount / Total**
5. Click **Save**
6. Note the **Billing Document Number** (e.g., 9000XXXX)
7. **SAP automatically creates Accounting Entry:**
   - Dr: Customer (TechMart) A/R Account
   - Cr: Revenue Account

> **Print Invoice:** VF02 → Enter Billing Doc → Issue Output (Output Type: RD00)

---

## STEP 7 — Post Incoming Payment

**T-Code:** `F-28`  
**Menu Path:** Accounting → Financial Accounting → Accounts Receivable → Document Entry → Incoming Payments

### What it is:
Records that the customer has paid the invoice. Clears the open AR item.

### How to do it:
1. Open transaction `F-28`
2. Fill in:
   - **Document Date / Posting Date:** Today
   - **Company Code:** 1000
   - **Currency:** INR / USD
   - **Bank Account:** (House Bank GL Account)
   - **Amount:** Invoice amount
   - **Customer:** TechMart account number
3. Click **Process Open Items**
4. Select the open invoice
5. Verify **Not Assigned = 0.00** (fully matched)
6. Click **Post** (Ctrl+S)
7. **Accounting Entry created:**
   - Dr: Bank Account
   - Cr: Customer A/R Account

---

## STEP 8 — Verify Document Flow

**T-Code:** `VA03`

### How to check:
1. Open `VA03` → Enter Sales Order Number
2. Go to **Environment → Document Flow**
3. You should see the complete chain:

```
Inquiry (VA11)
    └── Quotation (VA21)
            └── Sales Order (VA01)
                    └── Outbound Delivery (VL01N)
                            └── Goods Issue (VL02N)
                                    └── Billing Document (VF01)
                                            └── Accounting Document (FI)
                                                    └── Payment Clearing (F-28)
```

All documents should show **green** status — O2C cycle is COMPLETE ✅

---

## Summary of Key T-Codes

| Transaction | T-Code | Module |
|-------------|--------|--------|
| Create Inquiry | VA11 | SD |
| Create Quotation | VA21 | SD |
| Create Sales Order | VA01 | SD |
| Display Sales Order | VA03 | SD |
| Create Outbound Delivery | VL01N | SD/MM |
| Change Delivery / PGI | VL02N | SD/MM |
| Create Billing Document | VF01 | SD |
| Display Billing Document | VF03 | SD |
| Post Incoming Payment | F-28 | FI |
| Clear Open Items | F-32 | FI |
| Customer Line Item Report | FBL5N | FI |

---

## Tips for Screenshots

Take screenshots at these exact moments:
1. After saving **Inquiry** — show the document number
2. After saving **Quotation** — show pricing
3. After saving **Sales Order** — show availability check green
4. After **Goods Issue** posted — show success message
5. After **Billing** saved — show net value and accounting doc
6. **Document Flow** screen — most important screenshot
7. **FBL5N** — show cleared customer line items

---

*End of Step-by-Step Guide*
