# Screenshots Folder

Add your SAP screenshots here with the following names:

| File Name | What to Capture |
|-----------|----------------|
| 01_Inquiry_VA11.png | Inquiry creation screen with document number |
| 02_Quotation_VA21.png | Quotation with pricing conditions |
| 03_SalesOrder_VA01.png | Sales Order confirmed with ATP check |
| 04_Delivery_VL01N.png | Outbound delivery document |
| 05_GoodsIssue_VL02N.png | Goods Issue posted success message |
| 06_Billing_VF01.png | Invoice with net value and tax |
| 07_Accounting_Entry.png | FI accounting document (Dr/Cr entries) |
| 08_Payment_F28.png | Incoming payment posting |
| 09_DocumentFlow.png | Full O2C document flow chain |

**How to take screenshots in SAP:**
- Press **Print Screen** key on keyboard
- Or use **System → List → Save → Local File**
- Or press **Ctrl+P** for print preview then screenshot
